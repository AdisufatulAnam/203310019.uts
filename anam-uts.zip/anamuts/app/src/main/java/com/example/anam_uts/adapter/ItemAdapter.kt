package com.example.anam_uts.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.arifsutriyono.utssmt4.R
import com.arifsutriyono.utssmt4.model.dataKata

//import beberapa library yang dibutuhkan untuk menampilkan text dan juga gambar pada layout
class ItemAdapter (
    private val context:Context ,
    private val dataset:List<dataKata>
):RecyclerView.Adapter<ItemAdapter.ItemViewHolder>()
{
    //pada bagian ini melakukan deklarasi objek context dan juga  data set
    class ItemViewHolder(private val view: View): RecyclerView.ViewHolder(view) {
        val textView: TextView =view.findViewById(R.id.item_title)//melakukan import data string dari data source
        val imageView: ImageView =view.findViewById(R.id.item_image)//melakukan import data string dari data source
    }

//menentukan layout  untuk daftar yang akan ditampilkan

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        val adapterLayout = LayoutInflater.from(parent.context)
            .inflate(R.layout.list_item, parent, false)
        return ItemViewHolder(adapterLayout)
    }
    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        val item = dataset[position]
        holder.textView.text =  context.resources.getString(item.stringResourceId)//menggambil  text dari file string recource
        holder.imageView.setImageResource(item.imageResourceId)//mengambil text dari imageResource
    }
    //untuk menghitung ukuran file gambar.
    override fun getItemCount(): Int {
        return dataset.size
    }

}